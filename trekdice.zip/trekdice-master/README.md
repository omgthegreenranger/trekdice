Credits

This dice set is a modified Nice-More-Dice module (https://github.com/LyncsCwtsh/fvtt-module-Nice-more-Dice), with everything stripped away and a single dice set added.

The dice faces were taken from the Star Trek Adventures system module (https://github.com/mkscho63/sta)


